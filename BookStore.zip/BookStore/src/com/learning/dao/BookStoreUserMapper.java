package com.learning.dao;

import java.util.List;

import com.learning.pojo.BookStoreUser;

//user mapper ��
public interface BookStoreUserMapper {

	int addOne(BookStoreUser user);
	List<BookStoreUser> findAll();
	BookStoreUser findUserById(int id);
	List<BookStoreUser> findUserByCondition(BookStoreUser user);
	int updateUser(BookStoreUser user);
	int deleteUsers(String[] list);
	int deleteUser(String id);
	int getUserByName(String user_name);
	BookStoreUser login(BookStoreUser user);
	
	
}
