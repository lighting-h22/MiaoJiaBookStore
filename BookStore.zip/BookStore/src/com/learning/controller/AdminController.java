package com.learning.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@RequestMapping("/s")
	public ModelAndView handle() {
		
		ModelAndView modelAndView = new ModelAndView();	
		modelAndView.addObject("saying", "HelloWorld");
		modelAndView.setViewName("admin/admin_index");
		return modelAndView;
	}
	
	
	
}
