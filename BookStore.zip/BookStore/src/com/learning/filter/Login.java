package com.learning.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet Filter implementation class Login
 */
@WebFilter("/login")
public class Login implements Filter {

    
    public Login() {
        // TODO Auto-generated constructor stub
    }

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//���������Ĳ��������޸�
		HttpServletRequest req= (HttpServletRequest)request;
		HttpServletResponse resp= (HttpServletResponse)response;
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		//��ȡ���������и�ʽ�жϣ����Ϊ�����������ݿ���в���
		String tagName = request.getParameter("tagName");
		String password = request.getParameter("password");	
		boolean nameIsFormat = Pattern.compile("[a-zA-Z0-9_]+").matcher(tagName).matches();
		boolean emailIsFormat  = Pattern.compile("^\\w+([-+.]\\w+)*@(\\w+-?\\w+)(\\.\\w+-?\\w+)+$").matcher(tagName).matches();
		BookStoreUser user = new BookStoreUser();
		if(nameIsFormat) {
			user.setUser_name(tagName);
		}
		else if(emailIsFormat) {
			user.setUser_email(tagName);
		}
		else {
			PrintWriter writer = resp.getWriter();
			writer.write("<script>");
			writer.write("alert('�����ʽ������Ҫ��');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
			return;	
		}
		user.setUser_password(password);
		req.setAttribute("user", user);
		System.out.println("filter : " + user);
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
