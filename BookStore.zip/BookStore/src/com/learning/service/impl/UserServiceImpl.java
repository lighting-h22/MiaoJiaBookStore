package com.learning.service.impl;

import org.springframework.stereotype.Service;

import com.learning.dao.BookStoreUserMapper;

@Service("userServiceImpl")
public class UserServiceImpl {
	
	public void working() {
		System.out.println(this.getClass().getName()+" working");
	}

}
