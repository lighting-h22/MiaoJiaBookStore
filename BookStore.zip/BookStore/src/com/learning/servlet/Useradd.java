package com.learning.servlet;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class Useradd
 */
@WebServlet("/admin/useradd")
public class Useradd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//�����ַ���
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		//��ȡ�û������ֵ
		String username = request.getParameter("username");
		String pwd = request.getParameter("password");
		String sex = request.getParameter("sex");
		String birthday = request.getParameter("birthday");
		String identitycode = request.getParameter("identitycode");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String address = request.getParameter("address");
		String imgurl = request.getParameter("img");
		String role = request.getParameter("colId");
		
		//�����û�ʵ��
		BookStoreUser user = new BookStoreUser("1",username,pwd,sex,birthday,identitycode,email,mobile,address,role,imgurl);
		System.out.println(user);
		//���ʵ��
		SqlSession sqlSession = DBUtils.getSession();
		 BookStoreUserMapper userMapper = sqlSession.getMapper(BookStoreUserMapper.class); 	
		 int i = userMapper.addOne(user);
		 sqlSession.close();
		 //�û����ӳɹ�
		if(i>0) {
			response.sendRedirect("/BookStore/admin/findusers");
		}
		//�û�����ʧ��
		else {
			PrintWriter writer = response.getWriter();
			writer.write("<script>");
			writer.write("alter('�û�����ʧ�ܣ���');");
			writer.write("location.href('admin/admin_useradd.jsp');");
			writer.write("</script>");
		}
		System.out.println("###########"+this.getServletName()+"###########");
	}

}
