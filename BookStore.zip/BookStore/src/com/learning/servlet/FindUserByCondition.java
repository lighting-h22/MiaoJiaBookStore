package com.learning.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;


@WebServlet("/admin/findUserByCondition")
public class FindUserByCondition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		//���ò�ѯ����,,Ĭ��Ϊ�û���
		String condition = request.getParameter("condition");
		if(condition==null) {
			condition="user_name";
		}
		System.out.println(condition);
		//���ò�ѯ����,Ĭ��Ϊ��
		String keywords = request.getParameter("keywords");
		if(keywords==null)
			keywords="";
		String pageSize = (String) request.getServletContext().getInitParameter("pageSize");
		int defaultPageSize = 8;
		try {
			defaultPageSize = Integer.parseInt(pageSize);
		}catch (Exception e) {
			System.err.println("���������Ϊ���֣�");
		}
		
		String pageNum = request.getParameter("pageNum");
		int defaultPageNum = 1;
		try {
			
			if(pageNum!=null)
				defaultPageNum=Integer.parseInt(pageNum);
		}catch (NumberFormatException e) {
			System.err.println("������ƥ�䣡");
		}
		
		BookStoreUser user = new BookStoreUser();
		//������������
		try {
			Class<BookStoreUser> clazz = BookStoreUser.class;
			//��ȡ��������
			Field field = clazz.getDeclaredField(condition);
			//�޸�Ȩ��
			field.setAccessible(true);
			//�޸�����ֵ
			field.set(user,keywords);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SqlSession sqlSession = DBUtils.getSession();
		 BookStoreUserMapper userMapper = sqlSession.getMapper(BookStoreUserMapper.class); 	
		 //pageHelper����
		 PageHelper.startPage(defaultPageNum, defaultPageSize);
		 List<BookStoreUser> list = userMapper.findUserByCondition(user);
		 request.setAttribute("findAllUser", list);
		 System.out.println(list);
		 		 
		 
		 if(list==null)	{
			 
			PrintWriter writer = response.getWriter();
			writer.write("<script>");
			writer.write("alter('���û�');");
			response.sendRedirect("/admin/admin_useradd.jsp");
			writer.write("</script>");		
			}
		 else {
			 //��ȡҳ����Ϣ
			 PageInfo<BookStoreUser> info = new PageInfo<>(list);
			 int nextPage = info.getNextPage();
			 int prePage = info.getPrePage();
			 long total = info.getTotal();
			 int locatedPage = info.getPageNum();
			 int pages = info.getPages();
			 int size = info.getPageSize();
			 request.setAttribute("nextPage", nextPage);
			 request.setAttribute("prePage", prePage);
			 request.setAttribute("total", total);
			 request.setAttribute("locatedPage", locatedPage);
			 request.setAttribute("pages", pages);
			 request.setAttribute("userPageSize", size);
			 
			 request.getRequestDispatcher("/admin/admin_users.jsp").forward(request, response);	
		 }
	}

}
