package com.learning.utils;

import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class SpringUtil {
	
	public static ApplicationContext getApp(ServletContext context) {
		ApplicationContext app = WebApplicationContextUtils.getWebApplicationContext(context);
		return app;
	} 
	public static <T> T getService(Class t,ServletContext context) {
		ApplicationContext app = getApp(context);
		return (T) app.getBean(t);
	}

}
