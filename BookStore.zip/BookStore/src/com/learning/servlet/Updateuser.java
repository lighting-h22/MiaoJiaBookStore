package com.learning.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class Updateuser
 */
@WebServlet("/admin/updateuser")
public class Updateuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		//��ȡ�û������ֵ
		String userid = request.getParameter("userid");
		String username = request.getParameter("username");
		String pwd = request.getParameter("password");
		String sex = request.getParameter("sex");
		String birthday = request.getParameter("birthday");
		String identitycode = request.getParameter("identitycode");
		String email = request.getParameter("email");
		String mobile = request.getParameter("mobile");
		String address = request.getParameter("address");
		BookStoreUser user = new BookStoreUser();
		user.setUser_id(userid);
		user.setUser_name(username);
		user.setUser_password(pwd);
		user.setUser_sex(sex);
		user.setUser_birthday(birthday);
		user.setUser_identity_code(identitycode);
		user.setUser_email(email);
		user.setUser_mobile(mobile);
		user.setUser_address(address);
		System.out.println(user);

		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		int result = mapper.updateUser(user);
		System.out.println(result);
		if(result==0) {
			response.getWriter().write("<br>��������</br>");
		}
		else {
			PrintWriter writer = response.getWriter();
			writer.write("<script>");
			writer.append("alter('�޸ĳɹ���');");
			writer.append("</script>");
			response.sendRedirect("/BookStore/admin/findusers");
		}
		
	}

}
