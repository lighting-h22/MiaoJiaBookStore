package com.learning.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class Register
 */
@WebFilter("/register")
public class Register implements Filter {

    /**
     * Default constructor. 
     */
    public Register() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//���������Ĳ��������޸�
		HttpServletRequest req= (HttpServletRequest)request;
		HttpServletResponse resp= (HttpServletResponse)response;
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		//��ȡ�����������ж��Ƿ�Ϸ���ȡ�ý��
		String user_name = req.getParameter("user_name");
		String user_email = req.getParameter("user_email");
		String user_identity_code = req.getParameter("user_identity_code");
		String user_mobile = req.getParameter("user_mobile");
		boolean nameIsFormat = Pattern.compile("[a-zA-Z0-9_]+").matcher(user_name).matches();
		boolean emailIsFormat  = Pattern.compile("^\\w+([-+.]\\w+)*@(\\w+-?\\w+)(\\.\\w+-?\\w+)+$").matcher(user_email).matches();
		boolean identicodeIsFormat  = Pattern.compile("^\\d{15}|\\d{18}$").matcher(user_identity_code).matches();
		boolean mobileIsFormat  = Pattern.compile("^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$").matcher(user_mobile).matches();
		
		//
		if(!nameIsFormat) {
			PrintWriter writer = resp.getWriter();
			writer.write("<script>");
			writer.write("alert('���ָ�ʽ������Ҫ��ֻ��Ϊ���֡���ĸ');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
			return;	
			
		}
		if(!emailIsFormat) {
			PrintWriter writer = resp.getWriter();
			writer.write("<script>");
			writer.write("alert('�����ʽ������Ҫ��');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
			return;	
		}
		if(!identicodeIsFormat) {
			PrintWriter writer = resp.getWriter();
			writer.write("<script>");
			writer.write("alert('����֤��ʽ������Ҫ��');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
			return;	
		}
		if(!identicodeIsFormat) {
			PrintWriter writer = resp.getWriter();
			writer.write("<script>");
			writer.write("alert('����֤��ʽ������Ҫ��');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
			return;	
		}
		if(!mobileIsFormat) {
			PrintWriter writer = resp.getWriter();
			writer.write("<script>");
			writer.write("alert('�ֻ���ʽ��ʽ������Ҫ��');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
			return;	
		}
		chain.doFilter(request, response);
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
