package com.learning.test;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.service.impl.UserServiceImpl;
import com.learning.utils.SpringUtil;

/**
 * Servlet implementation class SpringTest
 */
@WebServlet("/springTest")
public class SpringTest extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserServiceImpl service = SpringUtil.getService(UserServiceImpl.class, request.getServletContext());
		service.working();
	}

}
