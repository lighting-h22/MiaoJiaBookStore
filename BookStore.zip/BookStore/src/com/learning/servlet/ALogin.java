package com.learning.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class ALogin
 */
@WebServlet("/admin/alogin")
public class ALogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String user_name = request.getParameter("user_name");
		String user_password = request.getParameter("user_password");
		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		BookStoreUser user=new BookStoreUser();
		user.setUser_name(user_name);
		user.setUser_password(user_password);
		user.setUser_status("2");
		
		BookStoreUser loginUser = mapper.login(user);
		if(loginUser!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", loginUser);
			request.getRequestDispatcher("admin_index.jsp").forward(request, response);
			
		}
		else {
			PrintWriter writer = response.getWriter();
			writer.append("<script>");
			writer.append("alert('����������޴��û�');");
			writer.append("window.location.href='admin_login.jsp';");
			writer.append("</script>");
			writer.close();
			
		
		}
		
	}

}
