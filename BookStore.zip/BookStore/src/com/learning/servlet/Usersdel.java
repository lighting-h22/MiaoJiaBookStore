package com.learning.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.env.SystemEnvironmentPropertySource;

import com.learning.dao.BookStoreUserMapper;
import com.learning.utils.DBUtils;


@WebServlet("/admin/usersdel")
public class Usersdel extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		String[] values = request.getParameterValues("id[]");
		System.out.println(values);
		List<Integer> list= new ArrayList<>();
		try {
			for(String v : values) {
				list.add(Integer.parseInt(v));
				System.out.println(v);
			}
		}catch(NumberFormatException e) {
			System.err.println("�ַ�ת�����󣡣�");
		}
		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		int result = mapper.deleteUsers(values);
		if(values!=null) {
			PrintWriter writer = response.getWriter();
			writer.append("<script>");
			if(result==0) {
				writer.append("$(function(){alert('ɾ��ʧ�ܣ�');}");
				
			}
			else {
				writer.append("$(function(){alert('�ѳɹ�ɾ����');}");
				
			}
			writer.append("</script>");
			response.sendRedirect("/BookStore/admin/findusers");
		}
		else {
			PrintWriter writer = response.getWriter();
			writer.append("<script>");
			writer.append("$(function(){alert('����ѡ�У���');}");
			writer.append("</script>");
			response.sendRedirect("/BookStore/admin/findusers");
		}
		
	}

}
