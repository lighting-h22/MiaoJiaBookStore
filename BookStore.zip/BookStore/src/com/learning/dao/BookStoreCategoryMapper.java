package com.learning.dao;

import java.util.List;

import com.learning.pojo.BookStoreCategory;

public interface BookStoreCategoryMapper {
	
	List<BookStoreCategory> findAll();
	int addOne();
	BookStoreCategory findCategoryById (String id);
	BookStoreCategory findCategoryByName(String name);
	BookStoreCategory findCategoryByCondition(BookStoreCategory category);
	int updateCategory(BookStoreCategory c);
	int deleteCategory(String id);
	
	int deleteCategories(List<String> list);
	

}
