package com.learning.userservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class Register
 */
@WebServlet("/register")
public class Register extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		
		String user_name = request.getParameter("user_name");
		String user_password = request.getParameter("user_password");
		String user_birthday = request.getParameter("user_birthday");
		String user_identity_code = request.getParameter("user_identity_code");
		String user_email = request.getParameter("user_email");
		String user_mobile = request.getParameter("user_mobile");
		
		BookStoreUser user = new BookStoreUser();
		
		user.setUser_name(user_name);
		user.setUser_password(user_password);
		user.setUser_birthday(user_birthday);
		user.setUser_sex("��");
		user.setUser_identity_code(user_identity_code);
		user.setUser_email(user_email);
		user.setUser_mobile(user_mobile);
		user.setUser_status(1+"");
		
		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		int result = mapper.addOne(user);
		PrintWriter writer = response.getWriter();
		if(result!=0) {
			writer.append("<script>");
			writer.append("alert('ע��ɹ�');");
			writer.append("window.location.href='login.jsp';");
			writer.append("</script>");
			
			writer.close();
			
			
		}else {
			
			writer.append("<script type=\"text/javascript\">");
			writer.append("alert('ע��ʧ��');");
			writer.append("window.location.href='register.jsp';");
			writer.append("</script>");
			
			writer.close();
			
			
		}
		
		
	}

}
