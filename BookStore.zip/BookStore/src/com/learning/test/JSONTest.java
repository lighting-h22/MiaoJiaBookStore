package com.learning.test;

import java.util.List;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;
import com.learning.utils.JSONUtil;

import net.sf.json.JSONArray;



public class JSONTest {
	public static void main(String[] args) {
		
		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		List<BookStoreUser> list = mapper.findAll();
		
		System.out.println(JSONUtil.listToJSON(list));
	}

}
