package com.learning.userservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.dao.BookStoreUserMapper;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class Checkusername
 */
@WebServlet("/checkusername")
public class Checkusername extends HttpServlet {

    /**
     * ��ȡ�û�����,�����ݿ�����û��Ƿ����,ͨ���жϽ������������
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		String user_name = request.getParameter("user_name");
		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		
		int result = mapper.getUserByName(user_name);
		
		PrintWriter writer = response.getWriter();
		//�жϷ�������
		if(result>0)
			writer.print("false");
		else
			writer.print("true");	
		writer.close();
		
	}
}
