package com.learning.pojo;

public class BookStoreOrder {
	
	private String order_id;
	private String order_name;
	private String order_type;
	private String order_user_id;
	private String order_detial;
	private String order_price;
	private String order_book_id;
	private String order_original_location;
	private String order_ending_location;
	private String order_status;
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getOrder_name() {
		return order_name;
	}
	public void setOrder_name(String order_name) {
		this.order_name = order_name;
	}
	public String getOrder_type() {
		return order_type;
	}
	public void setOrder_type(String order_type) {
		this.order_type = order_type;
	}
	public String getOrder_user_id() {
		return order_user_id;
	}
	public void setOrder_user_id(String order_user_id) {
		this.order_user_id = order_user_id;
	}
	public String getOrder_detial() {
		return order_detial;
	}
	public void setOrder_detial(String order_detial) {
		this.order_detial = order_detial;
	}
	public String getOrder_price() {
		return order_price;
	}
	public void setOrder_price(String order_price) {
		this.order_price = order_price;
	}
	public String getOrder_book_id() {
		return order_book_id;
	}
	public void setOoder_user_id(String order_book_id) {
		this.order_book_id = order_book_id;
	}
	public String getOrder_original_location() {
		return order_original_location;
	}
	public void setOrder_original_location(String order_original_location) {
		this.order_original_location = order_original_location;
	}
	public String getOrder_ending_location() {
		return order_ending_location;
	}
	public void setOrder_ending_location(String order_ending_location) {
		this.order_ending_location = order_ending_location;
	}
	public String getOrder_status() {
		return order_status;
	}
	public void setOrder_status(String order_status) {
		this.order_status = order_status;
	}
	public BookStoreOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookStoreOrder(String order_id, String order_name, String order_type, String order_user_id,
			String order_detial, String order_price, String order_book_id, String order_original_location,
			String order_ending_location, String order_status) {
		super();
		this.order_id = order_id;
		this.order_name = order_name;
		this.order_type = order_type;
		this.order_user_id = order_user_id;
		this.order_detial = order_detial;
		this.order_price = order_price;
		this.order_book_id = order_book_id;
		this.order_original_location = order_original_location;
		this.order_ending_location = order_ending_location;
		this.order_status = order_status;
	}
	@Override
	public String toString() {
		return "BookStoreOrder [order_id=" + order_id + ", order_name=" + order_name + ", order_type=" + order_type
				+ ", order_user_id=" + order_user_id + ", order_detial=" + order_detial + ", order_price=" + order_price
				+ ", order_book_id=" + order_book_id + ", order_original_location=" + order_original_location
				+ ", order_ending_location=" + order_ending_location + ", order_status=" + order_status + "]";
	}
	
	
	

}
