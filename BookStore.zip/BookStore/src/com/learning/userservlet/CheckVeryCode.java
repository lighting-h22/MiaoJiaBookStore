package com.learning.userservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;

/**
 * Servlet implementation class CheckVeryCode
 */
@WebServlet("/checkVeryCode")
public class CheckVeryCode extends HttpServlet {
	
	/**
	 * �첽�����֤���Ƿ���ȷ
	 * ��session�л�ȡcode���Եľ���ֵ
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String num = request.getParameter("num");
		HttpSession session = request.getSession();
		String code = (String) session.getAttribute("code");
		
		PrintWriter writer = response.getWriter();
		
		if(code.equals(num)) {
			writer.write("true");
			
		}else {
			writer.write("false");

		}
		writer.close();
	
		
	}

	
	

}
