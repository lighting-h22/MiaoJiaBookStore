package com.learning.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.dao.BookStoreUserMapper;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class Userdel
 */
@WebServlet("/admin/userdel")
public class Userdel extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String value = request.getParameter("user");
		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		int result = mapper.deleteUser(value);
		if(value!=null) {
			PrintWriter writer = response.getWriter();
			writer.append("<script>");
			if(result==0) {
				writer.append("$(function(){alert('ɾ��ʧ�ܣ�');}");
				
			}
			else {
				writer.append("$(function(){alert('�ѳɹ�ɾ����');}");
				
			}
			writer.append("</script>");
		}
		else {
			PrintWriter writer = response.getWriter();
			writer.append("<script>");
			writer.append("$(function(){alert('����ѡ�У���');}");
			writer.append("</script>");
			
		}
		response.sendRedirect("/BookStore/admin/findusers");
	}

}
