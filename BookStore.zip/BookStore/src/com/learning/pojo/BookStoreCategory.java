package com.learning.pojo;

public class BookStoreCategory {
	private String category_id;
	private String category_name;
	private String category_pid;
	private String category_detail;
	public String getCategory_id() {
		return category_id;
	}
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public String getCategory_pid() {
		return category_pid;
	}
	public void setCategory_pid(String category_pid) {
		this.category_pid = category_pid;
	}
	public String getCategory_detail() {
		return category_detail;
	}
	public void setCategory_detail(String category_detail) {
		this.category_detail = category_detail;
	}
	public BookStoreCategory(String category_id, String category_name, String category_pid, String category_detail) {
		super();
		this.category_id = category_id;
		this.category_name = category_name;
		this.category_pid = category_pid;
		this.category_detail = category_detail;
	}
	public BookStoreCategory() {
		super();
	}
	@Override
	public String toString() {
		return "BookStoreCategory [category_id=" + category_id + ", category_name=" + category_name + ", category_pid="
				+ category_pid + ", category_detail=" + category_detail + "]";
	}
	

}
