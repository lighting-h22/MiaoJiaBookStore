function changeImg(img){
	
	img.src='getCode?'+new Date().getTime();
}

var flag = false;

//焦点集中
function focusItem(obj){
	if($(obj).attr('name')=='veryCode'){
		$(obj).next().next().html('').removeClass('error');
		
	}else{
		$(obj).next('span').html('').removeClass('error');
		
	}
	
}


//表单项输入验证
function checkItem(obj){
	var tipBox = $(obj).next('span');
	//检查所有的input是否存在错误
	switch($(obj).attr('name')){
		case 'user_name':
			if(obj.value==''){
				tipBox.html('用户名不能为空');
				tipBox.addClass('error');
				flag = false;
			}
			else{
				var url = "checkusername?user_name="+encodeURI($(obj).val())+"&"+new Date().getTime();
				//ajax 异步请求 判断用户是否存在
				$.get(url,function(data){
					if(data == "false"){
						
						tipBox.html('用户名已存在');
						tipBox.addClass('error');
						flag = false;
					}else{
						tipBox.html().removeClass('error');
						flag = true;
					}
					
				});
				
				
			}
			break;
		case 'user_password':
			if(obj.value==''){
				tipBox.html('用户密码不能为空');
				tipBox.addClass('error');
				flag = false;
			}else{
				flag = true;
			}
			break;
		case 'reuser_password':
			if(obj.value==''){
				tipBox.html('确认密码不能为空');
				tipBox.addClass('error');
				flag = false;
			}
			else{
				if($(obj).val()!=$('input[name="user_password"]').val()){
					tipBox.html('密码不一致');
					tipBox.addClass('error');
					$('input[name="reuser_password"]').html('');
					flag = false;
				}else{
					flag = true;
				}
				
			}
			break;
		case 'user_birthday':
			if(obj.value==''){
				tipBox.html('日期不能为空');
				tipBox.addClass('error');
				flag = false;
			}else{
				flag = true;
			}
			break;
		case 'user_identity_code':
			if(obj.value==''){
				tipBox.html('身份证不能为空');
				tipBox.addClass('error');
				flag = false;
			}else{
				flag = true;
			}
			break;
		case 'user_email':
			if(obj.value==''){
				tipBox.html('邮箱不能为空');
				tipBox.addClass('error');
				flag = false;
			}else{
				flag = true;
			}
			break;
		case 'user_mobile':
			if(obj.value==''){
				tipBox.html('手机不能为空');
				tipBox.addClass('error');
				flag = false;
			}else{
				flag = true;
			}
			break;
		case 'veryCode':
			
			var a=$(obj).next().next('span');
			if(obj.value==''){
				a.html('验证码不能为空');
				a.addClass('error');
				flag = false;
			}
			else{
				var url = "checkVeryCode?num="+encodeURI($(obj).val())+"&"+new Date().getTime();
				
				$.get(url, function(result){
					
					 if(result=="false"){
						 a.html('验证码不正确！');
						 a.addClass('error');
						 flag = false;
					 }
					 else{
						 a.html().removeClass('error');
						 flag = true;
					 }
				});
			}
			break;
		
	}
	
}

//表单提交验证
function checkFrom(from){
	var els = form.getElementByTagName("input");
	for(var i = 0;i<els.lenght;i++){
		if(els(i)!=null){
			checkItem(els(i));
		}
	}
	alert(flag);
	return flag;
	
}






