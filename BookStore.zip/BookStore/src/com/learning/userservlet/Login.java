package com.learning.userservlet;

import java.awt.print.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		BookStoreUser user = (BookStoreUser) request.getAttribute("user");
		System.out.println("Attribute : " + user);

		BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
		BookStoreUser loginUser = mapper.login(user);
		System.out.println("Login : " + loginUser);
		PrintWriter writer = response.getWriter();
		//�жϲ�ѯ������û��Ƿ���ڣ�������״̬
		if(loginUser==null) {
			System.out.println("loginUser==null");
			writer.write("<script>");
			writer.write("alert('�û�Ϊ��');");
			writer.write("window.document.location.href=history.go(-1);");
			writer.write("</script>");
			writer.close();
		}else {
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", loginUser);
			if(loginUser.getUser_status().equals("1")) {
				response.sendRedirect("index.jsp");
			}
			else {
				response.sendRedirect("admin/admin_index.jsp");
			}
			
		}
		
		
	}

}
