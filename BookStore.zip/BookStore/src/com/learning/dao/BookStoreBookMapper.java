package com.learning.dao;

import java.util.List;

import com.learning.pojo.BookStoreBook;



//user mapper ��
public interface BookStoreBookMapper {
	int addOne(BookStoreBook order) ;
	List<BookStoreBook> findAll();
	BookStoreBook findBookById(String id);
	List<BookStoreBook> getBookByName(String name);
	List<BookStoreBook> getBookByType(String  type);
	List<BookStoreBook> findBookByCondition(BookStoreBook order);
	int updateBook(BookStoreBook order);
	int deleteBook(String id );
	int deleteBooks(List<String> ids);
	
}
