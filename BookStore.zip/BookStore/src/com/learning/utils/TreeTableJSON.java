package com.learning.utils;

public class TreeTableJSON {
	
	private String name ;

	public TreeTableJSON() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TreeTableJSON(String name) {
		super();
		this.name = name;
	}
	

}
