package com.learning.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;
import com.learning.utils.DBUtils;

/**
 * Servlet implementation class GetInfoOfUser
 */
@WebServlet("/admin/getInfoOfUser")
public class GetInfoOfUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String id = request.getParameter("id");
		Integer userId=null;
		try {
			userId = Integer.parseInt(id);
		}catch (NumberFormatException e) {
			System.err.println("�ַ���ת����ʧ�ܣ���");
		}
		
		//������������˳�
		if(userId==null) {
			PrintWriter writer = response.getWriter();
			writer.write("<script>");
			writer.write("alter('��������');");
			response.sendRedirect("/admin/findusers");
			writer.write("</script>");	
		}else {
			
			BookStoreUserMapper mapper = DBUtils.getSession().getMapper(BookStoreUserMapper.class);
			BookStoreUser user = mapper.findUserById(userId);
			
			//δ�ҵ��û����˳�
			if(user==null) {
				PrintWriter writer = response.getWriter();
				writer.write("<script>");
				writer.write("alter('�û�������');");
				response.sendRedirect("/admin/findusers");
				writer.write("</script>");	
			}
			else {
				request.setAttribute("beChangingUser", user);
				request.getRequestDispatcher("/admin/admin_modifyUser.jsp").forward(request, response);
				
			}
		}
		
	}

}
