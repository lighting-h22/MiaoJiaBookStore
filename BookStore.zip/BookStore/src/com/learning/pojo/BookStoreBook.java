package com.learning.pojo;

public class BookStoreBook {
	
	private String book_id;
	private String book_name;
	private String book_ISBN;
	private String book_author;
	private String book_publishing_house;
	private String book_publishing_time;
	private String book_price;
	private String book_introduction;
	private String book_category_id;
	public String getBook_category_id() {
		return book_category_id;
	}
	public void setBook_category_id(String book_category_id) {
		this.book_category_id = book_category_id;
	}
	public String getBook_id() {
		return book_id;
	}
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_ISBN() {
		return book_ISBN;
	}
	public void setBook_ISBN(String book_ISBN) {
		this.book_ISBN = book_ISBN;
	}
	public String getBook_author() {
		return book_author;
	}
	public void setBook_author(String book_author) {
		this.book_author = book_author;
	}
	public String getBook_publishing_house() {
		return book_publishing_house;
	}
	public void setBook_publishing_house(String book_publishing_house) {
		this.book_publishing_house = book_publishing_house;
	}
	public String getBook_publishing_time() {
		return book_publishing_time;
	}
	public void setBook_publishing_time(String book_publishing_time) {
		this.book_publishing_time = book_publishing_time;
	}
	public String getBook_price() {
		return book_price;
	}
	public void setBook_price(String book_price) {
		this.book_price = book_price;
	}
	public String getBook_introduction() {
		return book_introduction;
	}
	public void setBook_introduction(String book_introduction) {
		this.book_introduction = book_introduction;
	}
	public BookStoreBook() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BookStoreBook [book_id=" + book_id + ", book_name=" + book_name + ", book_ISBN=" + book_ISBN
				+ ", book_author=" + book_author + ", book_publishing_house=" + book_publishing_house
				+ ", book_publishing_time=" + book_publishing_time + ", book_price=" + book_price
				+ ", book_introduction=" + book_introduction + ", book_category_id=" + book_category_id + "]";
	}
	public BookStoreBook(String book_id, String book_name, String book_ISBN, String book_author,
			String book_publishing_house, String book_publishing_time, String book_price, String book_introduction,
			String book_category_id) {
		super();
		this.book_id = book_id;
		this.book_name = book_name;
		this.book_ISBN = book_ISBN;
		this.book_author = book_author;
		this.book_publishing_house = book_publishing_house;
		this.book_publishing_time = book_publishing_time;
		this.book_price = book_price;
		this.book_introduction = book_introduction;
		this.book_category_id = book_category_id;
	}
	
	

}
