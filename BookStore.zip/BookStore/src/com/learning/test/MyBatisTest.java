package com.learning.test;


import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.learning.dao.BookStoreUserMapper;
import com.learning.pojo.BookStoreUser;

public class MyBatisTest {
	public static void main(String[] args) throws IOException {
		MyBatisTest myBatisTest = new MyBatisTest();
		myBatisTest.testUserMapper();
		myBatisTest.tsetUserMapper2();
//		myBatisTest.tsetUserMapper3();
		
	}
	
	/*
	 * ��������һ���û� 
	 * @throws IOException
	 */
	@Test
	public int testUserMapper() throws IOException {
		 InputStream resourceAsStream = Resources.getResourceAsStream("com/learning/configure/mybatis-config.xml");
		 SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
		 SqlSession openSession = sqlSessionFactory.openSession(true);
		
		 BookStoreUserMapper userMapper = openSession.getMapper(BookStoreUserMapper.class);
		 BookStoreUser user = new BookStoreUser("1","��ӳ��","123456","��","1999-3-6","440611199903068961","5553353@qq.com","13123456789","�㶫ʡ�����дӻ���","1","com/img/01.jpg");
		 return userMapper.addOne(user);
		 
	}
	
	public void tsetUserMapper2() throws IOException {
		 InputStream resourceAsStream = Resources.getResourceAsStream("com/learning/configure/mybatis-config.xml");
		 SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
		 SqlSession openSession = sqlSessionFactory.openSession(true);
		 BookStoreUserMapper userMapper = openSession.getMapper(BookStoreUserMapper.class);
		 List<BookStoreUser> list = userMapper.findAll();
		 System.out.println(list);
	}
//	public void tsetUserMapper3() throws IOException {
//		InputStream resourceAsStream = Resources.getResourceAsStream("com/learning/configure/mybatis-config.xml");
//		 SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
//		 SqlSession openSession = sqlSessionFactory.openSession(true);
//		 BookStoreUserMapper userMapper = openSession.getMapper(BookStoreUserMapper.class);
//		 int count = userMapper.countAll();
//		 System.out.println("�ܹ�:"+count);
//	}

}
