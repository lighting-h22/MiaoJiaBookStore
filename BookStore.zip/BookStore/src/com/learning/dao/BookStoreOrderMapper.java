package com.learning.dao;

import java.util.List;

import com.learning.pojo.BookStoreOrder;



//user mapper ��
public interface BookStoreOrderMapper {

	int addOne(BookStoreOrder order) ;
	List<BookStoreOrder> findAll();
	BookStoreOrder findOrderById(String id);
	List<BookStoreOrder> getOrderByName(String name);
	List<BookStoreOrder> getOrderByType(String  type);
	List<BookStoreOrder> findOrderByCondition(BookStoreOrder order);
	int updateOrder(BookStoreOrder order);
	int deleteOrder(String id );
	int deleteOrders(List<String> ids);
	
}
