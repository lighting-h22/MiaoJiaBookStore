package com.learning.utils;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;



public class DBUtils {

	public static SqlSession getSession() {
		InputStream resourceAsStream = null;
		 SqlSessionFactory sqlSessionFactory = null;
		try {
			resourceAsStream = Resources.getResourceAsStream("com/learning/configure/mybatis-config.xml");
			
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 return sqlSessionFactory.openSession(true); 
	}
	
	
}
