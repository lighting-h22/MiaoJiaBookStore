package com.learning.pojo;

public class BookStoreUser {
	private String user_id;
	private String user_name; 
	private String user_password;
	private String user_sex; 
	private String user_birthday; 
	private String user_identity_code; 
	private String user_email; 
	private String user_mobile; 
	private String user_address; 
	private String user_status;
	private String user_imgurl;
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public String getUser_birthday() {
		return user_birthday;
	}
	public void setUser_birthday(String user_birthday) {
		this.user_birthday = user_birthday;
	}
	public String getUser_identity_code() {
		return user_identity_code;
	}
	public void setUser_identity_code(String user_identity_code) {
		this.user_identity_code = user_identity_code;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_mobile() {
		return user_mobile;
	}
	public void setUser_mobile(String user_mobile) {
		this.user_mobile = user_mobile;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public String getUser_status() {
		return user_status;
	}
	public void setUser_status(String user_status) {
		this.user_status = user_status;
	}
	public String getUser_imgurl() {
		return user_imgurl;
	}
	public void setUser_imgurl(String user_imgurl) {
		this.user_imgurl = user_imgurl;
	}
	@Override
	public String toString() {
		return "BookStoreUser [user_id=" + user_id + ", user_name=" + user_name + ", user_password=" + user_password
				+ ", user_sex=" + user_sex + ", user_birthday=" + user_birthday + ", user_identity_code="
				+ user_identity_code + ", user_email=" + user_email + ", user_mobile=" + user_mobile + ", user_address="
				+ user_address + ", user_status=" + user_status + ", user_imgurl=" + user_imgurl + "]";
	}
	public BookStoreUser(String user_id, String user_name, String user_password, String user_sex, String user_birthday,
			String user_identity_code, String user_email, String user_mobile, String user_address, String user_status,
			String user_imgurl) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.user_password = user_password;
		this.user_sex = user_sex;
		this.user_birthday = user_birthday;
		this.user_identity_code = user_identity_code;
		this.user_email = user_email;
		this.user_mobile = user_mobile;
		this.user_address = user_address;
		this.user_status = user_status;
		this.user_imgurl = user_imgurl;
	}
	public BookStoreUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
