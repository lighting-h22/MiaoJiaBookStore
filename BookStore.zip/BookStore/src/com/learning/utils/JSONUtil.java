package com.learning.utils;

import java.util.List;

import net.sf.json.JSONArray;

public class JSONUtil {
	
	public  static  String listToJSON(List<?> list) {
		JSONArray listArray=JSONArray.fromObject(list);
		return listArray.toString();
	}

}
